package com.niit.collab.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collab.dao.UserDAO;
import com.niit.collab.model.User;

public class UserTest 
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collab");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		User user = (User) context.getBean("user");
		
		user.setUsername("Mary");
		user.setPassword("123");
		user.setAddress("MUM");
		user.setEmail("mary@gmail");
		user.setEnabled("T");
		user.setRole("ROLE_ADMIN");
		
		//userDAO.saveOrUpdate(user);
		//userDAO.delete(3);
		if(userDAO.getUserByUsername("Mary")==null)
		{
			System.out.println("Name doesnt exit");
		}
		else
		{
			System.out.println("Name exist....");
			System.out.println();
		}
	
	}
}
