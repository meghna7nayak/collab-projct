package com.niit.collab.dao;

import java.util.List;

import com.niit.collab.model.Forum;


public interface ForumDAO {


	public List<Forum> get();
	public void add(Forum forum);
}
