package com.niit.collab.test;

import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collab.dao.ForumDAO;
import com.niit.collab.model.Forum;

public class ForumTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collab");
		context.refresh();
		
		ForumDAO forumDAO = (ForumDAO) context.getBean("forumDAO");
		Forum forum = (Forum) context.getBean("forum");
		
		forum.setForumdate(new Date());
		forum.setId(1);
		forum.setTitle("forum");
		forum.setUsername("Firstforum");
		
		forumDAO.add(forum);
	}

}
