package com.niit.collab.test;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collab.dao.BlogDAO;
import com.niit.collab.model.Blog;

public class BlogTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collab");
		context.refresh();
		
		BlogDAO blogDAO = (BlogDAO) context.getBean("blogDAO");
		Blog blog = (Blog) context.getBean("blog");
		
		blog.setId(1);
		blog.setBlogdate(new Date());
		blog.setBlogname("barbie5");
		blog.setDescription("cutie");
		blog.setUsername("Cgcf");
		
		//blogDAO.add(blog);
		
		List<Blog> l1 = blogDAO.get();
		System.out.println(l1);
	}

}
